# -*- coding: utf-8 -*-
"""
__title__ = ''
__author__ = 'yangyang'
__mtime__ = '2018.01.02'
"""
import os,sys
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)
print(BASE_DIR)

from package02.classTwo import classTwo
class classOne:
    def __init__(self):
        self.name = "class one"

    def printInfo(self):
        print("i am class One!")


if __name__ == "__main__":

    c2 = classTwo()
    c2.printInfo()