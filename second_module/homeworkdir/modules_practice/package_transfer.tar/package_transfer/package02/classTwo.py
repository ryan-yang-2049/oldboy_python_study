# -*- coding: utf-8 -*-
"""
__title__ = ''
__author__ = 'yangyang'
__mtime__ = '2018.01.02'
"""


class classTwo:
    def __init__(self):
        self.name = "class two"

    def printInfo(self):
        print("i am class two!")

