# -*- coding: utf-8 -*-
"""
__title__ = ''
__author__ = 'yangyang'
__mtime__ = '2018.01.02'
"""

from package01.classOne import classOne
from package02.classTwo import classTwo

if __name__ == "__main__":
    c1 = classOne()
    c1.printInfo()
    c2 = classTwo()
    c2.printInfo()

