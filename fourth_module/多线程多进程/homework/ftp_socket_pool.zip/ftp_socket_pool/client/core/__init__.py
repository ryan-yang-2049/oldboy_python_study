# -*- coding: utf-8 -*-
"""
__title__ = '__init__.py.py'
__author__ = 'yangyang'
__mtime__ = '2018.02.02'
"""

import sys,os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)








'''
package_transfer/
├── demo.py
├── __init__.py
├── package01
│   ├── classOne.py
│   └── __init__.py
└── package02
    ├── classTwo.py
    └── __init__.py
'''

